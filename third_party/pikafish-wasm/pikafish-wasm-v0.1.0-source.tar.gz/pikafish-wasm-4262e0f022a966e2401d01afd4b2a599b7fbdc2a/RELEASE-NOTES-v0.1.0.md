Pikafish `6a59ee2f7b105bff64d9efc2692591107787e2b1` (2026-09-19) built for the browser with emsdk 3.1.74, plus the matching net.

| asset | sha256 | bytes |
|---|---|---|
| `pikafish.js` | `17bc398028450c4c56df27812324cca8e5af9e2c86662f4a0d7f5b328270df3a` | 80,121 |
| `pikafish.wasm` | `b437f89ca16a1ff9181878813d1991f60b22067dca6b3feb79a26033224a83b1` | 662,419 |
| `pikafish.nnue` | `7d13d73569a9b571ba0eb20cf1596247bc2a42738967e61afef6482b231e900e` | 50,706,378 |

The net is upstream's `master-net` asset as updated 2026-09-06, arch `(62083, 1024, 32, 32, 1)`, under Pikafish's NNUE-License (no commercial use without permission). Measured in Chromium, four threads: 1.4M nodes/s from the start position, `stop` answered in about 20 ms.
