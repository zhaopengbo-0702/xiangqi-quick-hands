#!/usr/bin/env bash
# One-time publish of the repo and the v0.1.0 release (the agent cannot create
# public surfaces). Run from anywhere: bash ~/projects/pikafish-wasm/publish.sh
set -euo pipefail
cd "$(dirname "$0")"
git add RELEASE-NOTES-v0.1.0.md publish.sh
git diff --cached --quiet || git commit -q -m "v0.1.0 release notes and publish script"
git push -u origin main
gh release create v0.1.0 \
  dist/pikafish.js dist/pikafish.wasm dist/pikafish.nnue dist/SHA256SUMS NNUE-License.md \
  --title "v0.1.0: Pikafish 6a59ee2 in the browser" \
  --notes-file RELEASE-NOTES-v0.1.0.md
gh release view v0.1.0 --json url,assets --jq '.url, (.assets[] | "\(.name) \(.size)")'
